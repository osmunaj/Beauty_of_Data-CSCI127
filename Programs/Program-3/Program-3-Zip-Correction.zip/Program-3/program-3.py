def list_sectors(file):
    print("GICS Sectors in the S&P 500".center(60, '-'))
    sp500 = open(file, 'r', errors="ignore")
    sp500.readline()
    sectors = []
    num = 1
    for line in sp500:
        listing = line.split(',')
        if(listing[2] not in sectors):
            sectors.append(listing[2])
    sp500.close()
    sectors.sort()
    for sector in sectors:
        print(str(num) + '. ' + sector)
        num +=1
    print(''.center(60, '-'))
    return sectors

def get_user_choice(sectors):
    i = int(input("Choose a sector (1-11)\n"))-1
    return sectors[i]

def get_securities_in_sector(file, sector):
    sp500 = open(file, 'r', errors="ignore")
    sp500.readline()
    securities = []
    for line in sp500:
        listing = line.split(',')
        if listing[2] == sector:
            securities.append([[listing[0]],[listing[1]],[listing[3]]])
    sp500.close()
    return(securities)

def generate_report(securities, sector):
    print("\n")
    report = ('Securities in sector titled "' + sector + '"\n\n')
    for i in range(int(len(securities)/3)):
        report +=(str(i+1)+ ") "+ str(securities[i][0])+ ", " + str(securities[i][1]) + ", " + str(securities[i][2]) + "\n")
    print(report)
    user = input("Would you like to save this report?\n").upper()
    if(user[0]=="Y"):
        print("Okey, will save report\n")
        fileName = input("What would you like to name your report?\n")
        f = open(fileName, "a")
        f.write(report)
        f.close
        print('\nYour report has been saved to "' + fileName+'". Thank you for your time!')
    else:
        print("\nOkey, will not save report.")
    
def main(file):
    sectors = list_sectors(file)
    sector = get_user_choice(sectors)
    securities = get_securities_in_sector(file, sector)
    generate_report(securities, sector)

main("sp500.csv")
